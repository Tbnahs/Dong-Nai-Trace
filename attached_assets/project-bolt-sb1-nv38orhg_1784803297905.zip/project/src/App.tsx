import DongNaiMap from "@/components/DongNaiMap";

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <DongNaiMap />
    </div>
  );
}

export default App;
