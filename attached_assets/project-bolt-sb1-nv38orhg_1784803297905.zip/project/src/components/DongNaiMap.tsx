import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { DONG_NAI_WARDS } from "@/data/wards";

const PROVINCE_GEOJSON_URL = "/geojson/province.geojson";
const WARDS_GEOJSON_URL = "/geojson/dongnai_wards.geojson";

const PALETTE = [
  "#6366f1", "#8b5cf6", "#ec4899", "#f43f5e", "#f97316",
  "#eab308", "#84cc16", "#22c55e", "#10b981", "#14b8a6",
  "#06b6d4", "#3b82f6",
];

function wardColor(code: string): string {
  const hash = code.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const base = PALETTE[hash % PALETTE.length];
  const lightness = 45 + (hash % 5) * 7;
  return adjustLightness(base, lightness / 100);
}

function adjustLightness(hex: string, lightness: number): string {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const h = rgbToHue(r, g, b);
  const s = max === min ? 0 : (max - min) / (1 - Math.abs(max + min - 1));
  return hslToHex(h, s, lightness);
}

function rgbToHue(r: number, g: number, b: number): number {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  if (d === 0) return 0;
  if (max === r) return ((g - b) / d) % 6;
  if (max === g) return (b - r) / d + 2;
  return (r - g) / d + 4;
}

function hslToHex(h: number, s: number, l: number): string {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h * 60) % 360) / 60 - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;
  if (h < 1) { r = c; g = x; }
  else if (h < 2) { r = x; g = c; }
  else if (h < 3) { g = c; b = x; }
  else if (h < 4) { g = x; b = c; }
  else if (h < 5) { r = x; b = c; }
  else { r = c; b = x; }
  const toHex = (v: number) => Math.round((v + m) * 255).toString(16).padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function isPointInProvince(latlng: L.LatLng, provinceData: GeoJSON.FeatureCollection): boolean {
  const point = [latlng.lng, latlng.lat];
  for (const feature of provinceData.features) {
    const geom = feature.geometry;
    if (!geom) continue;
    if (geom.type === "MultiPolygon") {
      for (const polygon of geom.coordinates as number[][][][]) {
        if (pointInPolygon(point, polygon)) return true;
      }
    } else if (geom.type === "Polygon") {
      if (pointInPolygon(point, geom.coordinates as number[][][])) return true;
    }
  }
  return false;
}

function pointInPolygon(point: number[], polygon: number[][][]): boolean {
  const inside = rayCast(point, polygon[0]);
  if (!inside) return false;
  for (let i = 1; i < polygon.length; i++) {
    if (rayCast(point, polygon[i])) return false;
  }
  return true;
}

function rayCast(point: number[], ring: number[][]): boolean {
  const [x, y] = point;
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i];
    const [xj, yj] = ring[j];
    const intersect =
      yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

export default function DongNaiMap() {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const wardLayerRef = useRef<L.GeoJSON | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const wardBoundsRef = useRef<Map<string, L.LatLngBounds>>(new Map());
  const selectedRef = useRef<string | null>(null);
  const provinceDataRef = useRef<GeoJSON.FeatureCollection | null>(null);

  const [selectedWard, setSelectedWard] = useState<string>("");
  const [hoveredName, setHoveredName] = useState<string>("");
  const [markerCoord, setMarkerCoord] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      zoomControl: false,
      attributionControl: false,
      preferCanvas: true,
      zoomSnap: 0.25,
      zoomDelta: 0.5,
      wheelPxPerZoomLevel: 120,
      inertia: true,
      inertiaDeceleration: 3000,
      worldCopyJump: true,
    });

    mapRef.current = map;

    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
      subdomains: "abcd",
      attribution: "&copy; OpenStreetMap &copy; CARTO",
    }).addTo(map);

    L.control.zoom({ position: "bottomright" }).addTo(map);

    const markerIcon = L.divIcon({
      className: "dn-marker",
      html: `<div class="dn-marker-pin"><div class="dn-marker-dot"></div><div class="dn-marker-pulse"></div></div>`,
      iconSize: [30, 42],
      iconAnchor: [15, 42],
    });

    Promise.all([
      fetch(PROVINCE_GEOJSON_URL).then((r) => r.json()),
      fetch(WARDS_GEOJSON_URL).then((r) => r.json()),
    ]).then(([provinceData, wardsData]) => {
      provinceDataRef.current = provinceData;

      const provinceLayer = L.geoJSON(provinceData, {
        style: {
          fillColor: "#1e293b",
          fillOpacity: 0.03,
          color: "#1e293b",
          weight: 3,
          opacity: 0.5,
          dashArray: "8 6",
        },
      });
      provinceLayer.addTo(map);

      const wardLayer = L.geoJSON(wardsData, {
        style: (feature) => {
          const code = feature?.properties?.code ?? "";
          return {
            fillColor: wardColor(code),
            fillOpacity: 0.55,
            color: "#ffffff",
            weight: 1.2,
            opacity: 0.9,
          };
        },
        onEachFeature: (feature, layer) => {
          const code = feature.properties?.code ?? "";
          const name = feature.properties?.fullName ?? "";
          wardBoundsRef.current.set(
            code,
            (layer as L.Layer & { getBounds: () => L.LatLngBounds }).getBounds()
          );

          layer.on({
            mouseover: (e) => {
              const lyr = e.target as L.Path;
              lyr.setStyle({
                weight: 2.5,
                color: "#0f172a",
                fillOpacity: 0.85,
              });
              lyr.bringToFront();
              setHoveredName(name);
            },
            mouseout: (e) => {
              if (selectedRef.current === code) return;
              const lyr = e.target as L.Path;
              wardLayerRef.current?.resetStyle(lyr);
              setHoveredName("");
            },
            click: (e) => {
              L.DomEvent.stopPropagation(e);
            },
          });
        },
      });
      wardLayerRef.current = wardLayer;
      wardLayer.addTo(map);

      const bounds = provinceLayer.getBounds();
      map.fitBounds(bounds, { padding: [30, 30] });
      const initialZoom = map.getZoom();
      map.setZoom(initialZoom - 0.5, { animate: true });

      setLoading(false);

      map.on("click", (e: L.LeafletMouseEvent) => {
        const latlng = e.latlng;
        if (!provinceDataRef.current || !isPointInProvince(latlng, provinceDataRef.current)) return;

        if (markerRef.current) {
          map.removeLayer(markerRef.current);
        }

        const marker = L.marker(latlng, { icon: markerIcon }).addTo(map);
        markerRef.current = marker;
        setMarkerCoord({ lat: latlng.lat, lng: latlng.lng });

        map.flyTo(latlng, Math.max(map.getZoom() + 2, 12), {
          duration: 1.2,
        });
      });
    });

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedWard || !mapRef.current || !wardLayerRef.current) return;

    const code = selectedWard;
    selectedRef.current = code;

    wardLayerRef.current.eachLayer((layer) => {
      const lyr = layer as L.Path;
      const featCode =
        ((layer as unknown as { feature?: { properties?: { code?: string } } })
          .feature?.properties?.code) ?? "";
      if (featCode === code) {
        lyr.setStyle({
          fillColor: "#f59e0b",
          fillOpacity: 0.85,
          color: "#b45309",
          weight: 3,
        });
        lyr.bringToFront();

        const bounds = wardBoundsRef.current.get(code);
        if (bounds) {
          mapRef.current!.flyToBounds(bounds, {
            padding: [50, 50],
            duration: 1.2,
            maxZoom: 14,
          });
        }
      } else {
        wardLayerRef.current!.resetStyle(lyr);
      }
    });
  }, [selectedWard]);

  return (
    <section className="relative w-full">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700 ring-1 ring-emerald-200">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Dữ liệu hành chính mới nhất sau sáp nhập 2025
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
              Bản đồ Đồng Nai
            </h2>
            <p className="mt-1 max-w-xl text-sm text-slate-500">
              Khám phá 95 xã/phường của tỉnh Đồng Nai. Click để đặt ghim, chọn khu vực từ danh sách để di chuyển nhanh.
            </p>
          </div>
        </div>

        <div className="relative overflow-hidden rounded-2xl bg-white shadow-xl ring-1 ring-slate-200/60">
          <div className="absolute right-3 top-3 z-[1000] flex flex-col gap-2 sm:right-4 sm:top-4">
            <div className="relative">
              <select
                value={selectedWard}
                onChange={(e) => setSelectedWard(e.target.value)}
                className="w-56 cursor-pointer appearance-none rounded-xl border border-slate-200 bg-white/95 py-2.5 pl-3 pr-9 text-sm font-medium text-slate-700 shadow-md backdrop-blur transition-all hover:border-slate-300 hover:shadow-lg focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-200 sm:w-64"
              >
                <option value="">-- Chọn xã/phường --</option>
                {DONG_NAI_WARDS.map((w) => (
                  <option key={w.code} value={w.code}>
                    {w.name}
                  </option>
                ))}
              </select>
              <svg
                className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>

          {hoveredName && (
            <div className="pointer-events-none absolute left-3 top-3 z-[1000] rounded-lg bg-slate-900/90 px-3 py-1.5 text-xs font-medium text-white shadow-lg backdrop-blur sm:left-4 sm:top-4">
              {hoveredName}
            </div>
          )}

          {markerCoord && (
            <div className="absolute bottom-3 left-3 z-[1000] rounded-lg bg-white/95 px-3 py-2 text-xs shadow-lg backdrop-blur ring-1 ring-slate-200 sm:bottom-4 sm:left-4">
              <div className="font-semibold text-slate-800">Vị trí ghim</div>
              <div className="text-slate-500">
                {markerCoord.lat.toFixed(5)}°, {markerCoord.lng.toFixed(5)}°
              </div>
            </div>
          )}

          {loading && (
            <div className="absolute inset-0 z-[1001] flex items-center justify-center bg-slate-50">
              <div className="flex flex-col items-center gap-3">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-200 border-t-emerald-500" />
                <p className="text-sm font-medium text-slate-500">Đang tải bản đồ...</p>
              </div>
            </div>
          )}

          <div ref={containerRef} className="h-[500px] w-full sm:h-[600px]" />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: "Xã/Phường", value: "95", sub: "đơn vị hành chính" },
            { label: "Diện tích", value: "12.737", sub: "km²" },
            { label: "Phường", value: "23", sub: "đơn vị" },
            { label: "Xã", value: "72", sub: "đơn vị" },
          ].map((s) => (
            <div
              key={s.label}
              className="rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200/60 transition-all hover:shadow-md"
            >
              <div className="text-2xl font-bold text-slate-900">{s.value}</div>
              <div className="text-sm font-medium text-slate-600">{s.label}</div>
              <div className="text-xs text-slate-400">{s.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
